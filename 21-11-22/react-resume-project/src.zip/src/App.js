import Mainroute from "./Pages/Mainroute";
import './App.css'

function App() {
  return (
    <>
    <Mainroute/>
    </>

  );
}

export default App;
